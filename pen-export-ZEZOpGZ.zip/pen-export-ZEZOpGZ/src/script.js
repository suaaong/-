function toggleInputFields() {
    const method = document.getElementById('calculationMethod').value;
    document.getElementById('cmInputs').style.display = method === 'cm' ? 'block' : 'none';
    document.getElementById('pyeongInput').style.display = method === 'pyeong' ? 'block' : 'none';
}

function calculate() {
    const method = document.getElementById('calculationMethod').value;
    let tiles = 0, rectangleStickers = 0, roundStickers = 0;

    if (method === 'cm') {
        const widthCm = parseFloat(document.getElementById('widthCm').value);
        const lengthCm = parseFloat(document.getElementById('lengthCm').value);
        if(widthCm > 0 && lengthCm > 0) {
            tiles = Math.ceil((widthCm * lengthCm) / 2500);
        }
    } else if (method === 'pyeong') {
        const pyeong = parseFloat(document.getElementById('pyeong').value);
        if(pyeong > 0) {
            tiles = Math.ceil(pyeong * 3.3 * 13);
        }
    }

    rectangleStickers = Math.ceil(tiles / 20);
    roundStickers = Math.ceil(tiles / 70);

    document.getElementById('results').innerHTML = `
        <p>
📌타일카페트 예상 주문량: <span>${tiles}장</span></p>
        <p>
📌사각스티커 예상 주문량: <span>${rectangleStickers}장</span></p>
        <p>
📌원형스티커 예상 주문량: <span>${roundStickers}장</span></p>
    `;
}

function toggleStickerInfo() {
    const details = document.getElementById('stickerDetails');
    details.style.display = details.style.display === 'none' ? 'block' : 'none';
}
